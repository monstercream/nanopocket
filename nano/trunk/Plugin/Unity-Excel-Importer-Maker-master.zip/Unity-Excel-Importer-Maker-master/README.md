#Unity-Excel-Importer-Maker

---

##How To Use(E)

1. import xls file  
![Alt text](https://github.com/tsubaki/Unity-Excel-Importer-Maker/blob/gh-pages/import%20excel.jpg?raw=true)


2. select xls file and **Create XLS Importer**  
![Alt text](https://github.com/tsubaki/Unity-Excel-Importer-Maker/blob/gh-pages/create%20xls%20importer.jpg?raw=true)

3. Push **create** button. then, it make importer in Terasurware/Classes/Editor.  
![Alt text](https://github.com/tsubaki/Unity-Excel-Importer-Maker/raw/gh-pages/push%20create%20button.jpg)

4. **ReImport the xls file**. so it make scriptable object same xls parameter.  
![Alt text](https://github.com/tsubaki/Unity-Excel-Importer-Maker/blob/gh-pages/scriptable%20object.jpg?raw=true)

##importer settings 

The class name : sheet name.  
The parameter name : header parameter.  
The parameter type : cell type. 
The asset file name : xls file name. 
  
![Alt text](https://github.com/tsubaki/Unity-Excel-Importer-Maker/blob/gh-pages/importer%20settings.jpg?raw=true)

#日本語資料
-  [Excelでデータを管理してUnity iOS/Androidで使うワークフローをノーコーディングで使えるようにした](http://tsubakit1.hateblo.jp/entry/20131010/1381411760)
-  [Unity-Excel-Importer-Maker 配列型に対応](http://tsubakit1.hateblo.jp/entry/20131102/1383322276)
-  [Unity-Excel-Importer-Makerのマルチシートに対応](http://tsubakit1.hateblo.jp/entry/20131123/1385185935)
-  [Excel Importer、同一ブックの複数フォーマット出力機能を追加](http://tsubakit1.hateblo.jp/entry/20140201/1391265935)
